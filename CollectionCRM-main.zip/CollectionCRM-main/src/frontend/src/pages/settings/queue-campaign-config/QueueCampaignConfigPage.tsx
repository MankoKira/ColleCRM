import React from 'react';
import QueueCampaignConfig from './components/QueueCampaignConfig';

const QueueCampaignConfigPage: React.FC = () => {
  return <QueueCampaignConfig />;
};

export default QueueCampaignConfigPage;