import React from 'react';
import AuditLog from './components/AuditLog';

const AuditLogPage: React.FC = () => {
  return <AuditLog />;
};

export default AuditLogPage;