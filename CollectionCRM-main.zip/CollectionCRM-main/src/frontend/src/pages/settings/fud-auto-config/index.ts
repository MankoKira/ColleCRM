export { default as FudAutoConfigPage } from './FudAutoConfigPage';
export { FudRuleModal } from './components/FudRuleModal';
export { default as FudAutoConfig } from './components/FudAutoConfig';