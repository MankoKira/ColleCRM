import FudAutoConfigPage from '../FudAutoConfigPage';

// Re-export the main page component
export default FudAutoConfigPage;