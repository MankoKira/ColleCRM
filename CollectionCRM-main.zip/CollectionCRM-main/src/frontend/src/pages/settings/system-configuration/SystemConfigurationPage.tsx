import React from 'react';
import SystemConfiguration from './components/SystemConfiguration';

const SystemConfigurationPage: React.FC = () => {
  return <SystemConfiguration />;
};

export default SystemConfigurationPage;